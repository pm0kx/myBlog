#encoding: utf-8

from flask import render_template,request,current_app
from datetime import datetime
from flask import redirect,url_for,jsonify
from app.common import logger
from flask_login import login_url,current_user,login_required
from app.common.time_util import *
from sqlalchemy import func

from . import admin
from app.models import User,Action,Resource,Group,Role,Tag,Mail,ActionLog,users_roles,roles_actions

logger = logger.Logger(logger="admin-api").getlog()

@admin.route('/get_users',methods=['GET'])
def users_page():
    return render_template("admin/users.html")

@admin.route('/users',methods=['GET'])
#@login_required
def user_list():
    #page = request.args.get('page', 1, type=int)
    page_size=request.args.get('rows', 5, type=int)
    page=request.args.get('page', 1, type=int)
    pagination = User.query.order_by(User.created_time.asc()).paginate(
        page, per_page=page_size,
        error_out=False)
    users = pagination.items

    prev = None
    if pagination.has_prev:
        prev = url_for('admin.user_list', page=page - 1)
    next = None
    if pagination.has_next:
        next = url_for('admin.user_list', page=page + 1)
    return jsonify({
        'rows': [user.to_json() for user in users],
        'prev': prev,
        'next': next,
        'total': pagination.total,
        'time': get_localtime()
    })

@admin.route('/users/<string:user_id>/detial')
def user_detial(user_id):
    user = User.query.get_or_404(user_id)
    return jsonify(user.to_json())


@admin.route('/roles/<string:role_id>/users',methods=['GET'])
def get_users_by_role(role_id):
    users = User.query.join(users_roles).join(Role).filter(Role.id == role_id)
    return jsonify({
        'rows': [user.to_json() for user in users],
        'total': users.count(),
        'time': get_localtime()
    })


@admin.route('/get_roles',methods=['GET'])
def roles_page():
    return render_template("admin/roles.html")


@admin.route('/roles',methods=['GET'])
def role_list():
    page_size=request.args.get('rows', 5, type=int)
    page=request.args.get('page', 1, type=int)

    pagination = Role.query.order_by(Role.created_time.asc()).paginate(
        page, per_page=page_size,
        error_out=False)
    roles = pagination.items
    prev = None

    if pagination.has_prev:
        prev = url_for('admin.role_list', page=page - 1)
    next = None
    if pagination.has_next:
        next = url_for('admin.role_list', page=page + 1)
    return jsonify({
        'rows': [role.to_json() for role in roles],
        'prev': prev,
        'next': next,
        'total': pagination.total,
        'time': get_localtime()
    })


@admin.route('/users/<string:user_id>/roles')
def get_roles_by_user(user_id):
    roles = Role.query.join(users_roles).join(User).filter(User.id == user_id)
    return jsonify({
        'rows': [role.to_json() for role in roles],
        'total': roles.count(),
        'time': get_localtime()
    })


@admin.route('/get_actions',methods=['GET'])
def actions_page():
    return render_template("admin/actions.html")


@admin.route('/actions',methods=['GET'])
def action_list():
    page_size=request.args.get('rows', 5, type=int)
    page=request.args.get('page', 1, type=int)

    pagination = Action.query.order_by(Action.created_time.asc()).paginate(
        page, per_page=page_size,
        error_out=False)
    actions = pagination.items
    logger.info(len(actions))
    prev = None

    if pagination.has_prev:
        prev = url_for('admin.action_list', page=page - 1)
    next = None
    if pagination.has_next:
        next = url_for('admin.action_list', page=page + 1)
    return jsonify({
        'rows': [action.to_json() for action in actions],
        'prev': prev,
        'next': next,
        'total': pagination.total,
        'time': get_localtime()
    })

@admin.route('/roles/<string:role_id>/actions',methods=['GET'])
def get_actions(role_id):
    actions = Action.query.join(roles_actions).join(Role).filter(Role.id == role_id)
    #actions_count = actions.query(func.count(Role.id)).scalar()

    return jsonify({
        'rows': [action.to_json() for action in actions],
        'total': actions.count(),   #数据量大后，可能是查询慢的一个原因
        'time': get_localtime()
    })

def action_log():
    pass

def group_list():
    pass


def tag_list():
    pass


def resource_list():
    pass


